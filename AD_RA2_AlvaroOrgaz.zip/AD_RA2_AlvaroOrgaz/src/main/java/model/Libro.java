package model;


public class Libro {
    private int nombre;
    private int generoId;
}

public Libro(int nombre, int generoId){
    this.nombre = nombre;
    this.generoId = generoId;
}

public int getNombre() {
    return nombre;
}

public void setNombre(int nombre) {
    this.nombre = nombre;

}

public int getGeneroId() {
    return generoId;
}

public void setGeneroId(int generoId) {
    this.generoId = generoId;
}
