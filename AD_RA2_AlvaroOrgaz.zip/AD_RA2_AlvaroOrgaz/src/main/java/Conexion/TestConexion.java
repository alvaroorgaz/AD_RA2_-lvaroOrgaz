package Conexion;

import java.sql.*;
import java.util.Properties;
import java.io.InputStream;
import java.io.IOException;


public class TestConexion {


    public static void main(String[] args) {
        Properties props = new Properties();



        try (InputStream input = TestConexion.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (input == null) {
                System.out.println("No se encontró el archivo db.properties");
                return;
            }
            props.load(input);
        } catch (IOException e) {
            System.out.println("Error al leer db.properties: " + e.getMessage());
            return;
        }


        String url = props.getProperty("db.url");
        String user = props.getProperty("db.user");
        String password = props.getProperty("db.password");


        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            System.out.println("Conexión establecida correctamente con la base de datos 'empresa'.");



        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
