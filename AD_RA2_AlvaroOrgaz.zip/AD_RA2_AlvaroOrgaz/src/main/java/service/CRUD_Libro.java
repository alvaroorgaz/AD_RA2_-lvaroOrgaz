package service;

import Conexion.TestConexion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CRUD_Libro {
    public int crear( libro) {
        String query = "INSERT INTO empleados (nombre,genero_id ) VALUES (?,?)";
        int idGenerado = -1;
        try (Connection conexion = TestConexion.getConnection()) {
            PreparedStatement statement = conexion.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
            statement.setString(1, libro.getNombre());
            statement.setString(2, libro.getGenero_id());
            statement.executeUpdate();
            var rs = statement.getGeneratedKeys();
            if (rs.next()) {
                idGenerado = rs.getInt(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return idGenerado;
    }


    public List<CRUD_Libro> obtenerTodos(){
        List<CRUD_Libro> listaProyectos = new ArrayList<>();
        String query = "SELECT * FROM proyectos";
        try (Connection conexion = TestConexion.getConnection()) {
            PreparedStatement statement = conexion.prepareStatement(query);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                Libro libro = new Proyecto();
                proyecto.setNombre(rs.getString("nombre"));
                proyecto.setGenero_id(rs.getString("genero_id"));
                listaProyectos.add(Libro);
            }    }
        catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return listaProyectos;

    }


    public boolean actualizar(Libro libro, int id) {
        String query = "UPDATE libro SET nombre=?, genero_id=? WHERE id=?";
        boolean actualizado = false;
        try(Connection conexion = TestConexion.getConnection()) {
            PreparedStatement statement = conexion.prepareStatement(query);
            statement.setString(1, libro.getNombre());
            statement.setString(2, libro.getEmail());
            statement.setInt(7, id);
            int filasAfectadas = statement.executeUpdate();
            actualizado = filasAfectadas > 0;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return actualizado;
    }
    public boolean eliminar(int id) {
        String query = "DELETE FROM libro WHERE id = ?";
        boolean eliminado = false;
        try (Connection conexion = TestConexion.getConnection()) {
            PreparedStatement statement = conexion.prepareStatement(query);
            statement.setInt(1, id);
            int filasAfectadas = statement.executeUpdate();
            eliminado = filasAfectadas > 0;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return eliminado;
    }





}

