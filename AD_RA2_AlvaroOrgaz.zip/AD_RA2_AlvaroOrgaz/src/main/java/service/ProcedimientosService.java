package service;

import Conexion.TestConexion;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class ProcedimientosService {
    public void actualizarIdCliente(int clienteId) {
        try(Connection conexion = TestConexion.getConnection()) {

            CallableStatement cs = conexion.prepareCall("{CALL actualizarCliente(?, ?)}");
            cs.setInt(1, clienteId);
            cs.execute();
            System.out.println("Id del cliente con ID " + clienteId + " actualizado");



        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }



    }



